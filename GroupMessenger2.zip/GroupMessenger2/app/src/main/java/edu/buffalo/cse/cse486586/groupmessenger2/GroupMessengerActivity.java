package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 *
 * @author stevko
 */
public class GroupMessengerActivity extends Activity {
    static final int SERVER_PORT = 10000;
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    static final String KEY = "key";
    static final String VALUE = "value";
    static String failPort = "";
    static AtomicInteger keySeqCount = new AtomicInteger(-1);
    static int sequenceAtServer = -1;
    static int sequenceAgreed = -1;
    static int uniqueId = 0;
    static int gvar = 0;
    Lock lock = new ReentrantLock();


    static final String TAG = GroupMessengerActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        TelephonyManager telMan = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = telMan.getLine1Number().substring(telMan.getLine1Number().length() - 4);
        final String myPort = String.valueOf(Integer.parseInt(portStr) * 2);
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
            Log.e(TAG, "ServerSocket created");
        } catch (IOException e) {
            Log.e(TAG, "ServerSocket can't be created" + e.getMessage());
            return;
        }

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());

        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));

        /*---- register and implementation of OnClickListener for the Send Button----*/

        final EditText editText = (EditText) findViewById(R.id.editText1);
        Button sendButton = (Button) findViewById(R.id.button4);
        sendButton.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                String msg = editText.getText().toString() + "\n";
                editText.setText(""); // This is one way to reset the input box.
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort);
            }
        });

        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */
    }

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    Uri contentUri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger2.provider");

    class msgObject extends Object {
        int seq, flag;
        String msg_id, msg, port_num;

        public msgObject(String msg_id, int seq, String msg, int flag, String port_num) {
            this.msg_id =  msg_id;
            this.seq = seq;
            this.msg = msg;
            this.flag = flag;
            this.port_num = port_num;
        }

        @Override
        public String toString() {
            return this.msg_id +":"+ this.seq + this.port_num;
        }
    }


    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {


        @Override
        protected Void doInBackground(ServerSocket... serverSockets) {

            ServerSocket serverSocket = serverSockets[0];
            while (true) {

                try {
                    Socket server = serverSocket.accept();

                    DataInputStream input = new DataInputStream(server.getInputStream());

                    String message_string = input.readLine();
                    if(message_string.equals("check"))
                    {
                        Log.e("Message String :", message_string);
                        continue;
                    }

                    DataOutputStream server_output = new DataOutputStream(server.getOutputStream());




                    String[] msgSplit = message_string.split(":");//splitting mesg string to obtain mesg_id


                    if (msgSplit[0].equals("REQUEST")) {
                        String message_id = msgSplit[1];
                        String port_number = msgSplit[2];
                        String message = msgSplit[3];
                        Log.i(TAG, "Server Task: " + message_id + " " + port_number + " " + message);

                        if (sequenceAtServer <= sequenceAgreed)
                            sequenceAgreed = sequenceAgreed + 1;
                        else
                            sequenceAgreed = sequenceAtServer + 1;

                        msgObject mo = new msgObject(message_id, sequenceAgreed, message, 0, port_number);
                        myQueue.add(mo);
                        Log.e("queue",myQueue.toString());
                        server.shutdownInput();
                        Log.e("osss",Boolean.toString(server.isOutputShutdown()) );
                        server_output.writeInt(mo.seq);
                        server_output.flush();


                    } else if (msgSplit[0].equals("AGREEMENT")) {

                        Log.e("received agreement",message_string);

                        String message_id = msgSplit[1];
                        String port_number = msgSplit[2];
                        String sequenceAgreed_1 = msgSplit[3];
                        String message = msgSplit[4];

                        Log.e("message_id :", message_id);
                        Log.e("port_number :", port_number);
                        Log.e("sequenceAgreed :", sequenceAgreed_1);
                        Log.e("message :", message);

                        if(Integer.parseInt(sequenceAgreed_1) > sequenceAtServer)
                            sequenceAtServer = Integer.parseInt(sequenceAgreed_1);

                        msgObject mo_new = new msgObject(message_id, Integer.parseInt(sequenceAgreed_1), message, 1, port_number);
                        for (msgObject msg : myQueue) {
                            if (msg.msg_id.equals(mo_new.msg_id)) {
                                Log.e("removing - queue",msg.msg_id);

                                Log.e("queue",myQueue.toString());
                                myQueue.remove(msg);
                                Log.e("adding - queue",msg.msg_id + sequenceAgreed_1);
                                myQueue.add(mo_new);

                                Log.e("queue",myQueue.toString());
                                break;
                            }

                        }
                        while (!myQueue.isEmpty() && myQueue.peek().flag == 1) {

                            msgObject obj = myQueue.remove();

                            ContentValues ValueToInsert = new ContentValues();
                            ValueToInsert.put(KEY, Integer.toString(keySeqCount.incrementAndGet()));
                            ValueToInsert.put(VALUE, obj.msg);
                            getContentResolver().insert(
                                    contentUri,
                                    ValueToInsert
                            );
                            publishProgress(obj.msg);

                        }
                    }
                }
                 catch (IOException e) {
                     e.printStackTrace();
                 }
            }
        }

        protected void onProgressUpdate(String... strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            String strReceived = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);
            remoteTextView.append(strReceived + "\t\n");

            return;
        }
    }

    Comparator<msgObject> comparator = new findLeastSeqNumber();
    PriorityQueue<msgObject> myQueue = new PriorityQueue<msgObject>(25, comparator);



    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
                Socket socket;

                /*---- from AVD to all other AVDs----*/

                int max = -1;
                String max_port = "";

                Log.e("AVD broadcasting", "sending message from AVD");
                for (int i = 0; i < 5; i++) {
                    Integer portInt = 11108 +(i*4);
                    String portStr = portInt.toString();

                    try {
                        socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(portStr));

                        String msgToSend = strings[0];
                        Log.i(TAG, strings[1]);
                        String portOfMesg = strings[1];
                        String newMsgId = Integer.toString(uniqueId) + portOfMesg;

                        msgToSend = "REQUEST" + ":" + newMsgId + ":" + portOfMesg + ":" + msgToSend;

                        DataOutputStream os;
                        os = new DataOutputStream(socket.getOutputStream());
                        os.writeBytes(msgToSend + " newMsgId= " + newMsgId);
                        os.flush();
                        DataInputStream input = new DataInputStream(socket.getInputStream());
                        int seq = input.readInt();
                        Log.e(TAG, "Server response: " + seq);
                        if(seq > max) {
                            max = seq;
                            max_port = portStr;
                        }
                        os.close();
                        input.close();

                    }

                        catch (Exception e)
                        {
                            e.printStackTrace();

                            Iterator it = myQueue.iterator();
                            while (it.hasNext())
                            {
                                msgObject object = (msgObject) it.next();
                                Log.e("check port ="+portStr,object.port_num +":"+object.flag);
                                if(object.port_num.equals(portStr) && object.flag == 0 ) {
                                    myQueue.remove(object);
                                    Log.e("removing obj-dead port",object.msg_id +":"+ object.port_num);
                                }


                            }
                            it = myQueue.iterator();
                            while (!myQueue.isEmpty() && myQueue.peek().flag == 1 )
                            {
                                msgObject object = myQueue.remove();

                                ContentValues ValueToInsert = new ContentValues();
                                ValueToInsert.put(KEY, Integer.toString(keySeqCount.incrementAndGet() ));
                                ValueToInsert.put(VALUE, object.msg);
                                getContentResolver().insert(
                                        contentUri,
                                        ValueToInsert
                                );
                            }


                        }

                }
                //multicast with agree sequence num


                for (int i = 0; i < 5; i++) {
                    Integer a =  (11108 +(i*4));
                    String portStr = a.toString();

                    try {
                        if (i == 0)
                            socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                    Integer.parseInt(REMOTE_PORT0));
                        else if(i == 1)
                            socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                    Integer.parseInt(REMOTE_PORT1));
                        else if(i == 2)
                            socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                    Integer.parseInt(REMOTE_PORT2));
                        else if(i == 3)
                            socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                    Integer.parseInt(REMOTE_PORT3));
                        else
                            socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                    Integer.parseInt(REMOTE_PORT4));
                        if (String.valueOf(socket.getPort()).equals(failPort)) {
                            socket.close();
                            continue;
                        }

                        String msgToSend = strings[0];

                        String portOfMesg = strings[1];
                        String newMsgId = Integer.toString(uniqueId) + portOfMesg;

                        msgToSend = "AGREEMENT:" + newMsgId + ":" + portOfMesg + ":" + max + ":" + msgToSend;

                        DataOutputStream os;
                        os = new DataOutputStream(socket.getOutputStream());
                        os.writeBytes(msgToSend + " newMsgId= " + newMsgId);
                        os.flush();
                        os.close();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                        e.printStackTrace();

                        Iterator it = myQueue.iterator();
                        while (it.hasNext())
                        {
                            msgObject object = (msgObject) it.next();
                            Log.e("check port ="+portStr,object.port_num +":"+object.flag);
                            if(object.port_num.equals(portStr) && object.flag == 0 ) {
                                myQueue.remove(object);
                                Log.e("removing obj-dead port",object.msg_id +":"+ object.port_num);
                            }


                        }
                        it = myQueue.iterator();
                        while (!myQueue.isEmpty() && myQueue.peek().flag == 1 )
                        {
                            msgObject object = myQueue.remove();

                            ContentValues ValueToInsert = new ContentValues();
                            ValueToInsert.put(KEY, Integer.toString(keySeqCount.incrementAndGet() ));
                            ValueToInsert.put(VALUE, object.msg);
                            getContentResolver().insert(
                                    contentUri,
                                    ValueToInsert
                            );
                        }
                    }

                }
                    uniqueId++;

            return null;
        }
    }

//class to estimate the message with least sequence number and in case if they are equal, we will compare it on the basis
    // of smaller port  number.

    class findLeastSeqNumber implements Comparator<msgObject> {
        @Override
        public int compare(msgObject o1, msgObject o2) {
            if (o1.seq < o2.seq)
                return -1;
            else if (o1.seq > o2.seq)
                return 1;
            else {
                if (Integer.parseInt(o1.port_num) < Integer.parseInt(o2.port_num))
                    return -1;
                else
                    return 1;
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
}
