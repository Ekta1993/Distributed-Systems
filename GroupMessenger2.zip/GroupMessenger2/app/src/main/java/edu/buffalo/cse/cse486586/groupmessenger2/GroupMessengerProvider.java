package edu.buffalo.cse.cse486586.groupmessenger2;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;

import java.sql.SQLException;

/**
 * GroupMessengerProvider is a key-value table. Once again, please note that we do not implement
 * full support for SQL as a usual ContentProvider does. We re-purpose ContentProvider's interface
 * to use it as a key-value table.
 * 
 * Please read:
 * 
 * http://developer.android.com/guide/topics/providers/content-providers.html
 * http://developer.android.com/reference/android/content/ContentProvider.html
 * 
 * before you start to get yourself familiarized with ContentProvider.
 * 
 * There are two methods you need to implement---insert() and query(). Others are optional and
 * will not be tested.
 * 
 * @author stevko
 *
 */
public class GroupMessengerProvider extends ContentProvider {

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // You do not need to implement this.
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        {

            SQLiteDatabase myDB= null;
            try {
                myDB = new SQLiteDatabase(this.getContext());
            } catch (SQLException e) {
                e.printStackTrace();
            }
            android.database.sqlite.SQLiteDatabase sqlDatabase = myDB.getWritableDatabase();

            sqlDatabase.insertWithOnConflict("GrpMessenger",null,values,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);

            sqlDatabase.close();


        }

        /*
         * TODO: You need to implement this method. Note that values will have two columns (a key
         * column and a value column) and one row that contains the actual (key, value) pair to be
         * inserted.
         *
         * For actual storage, you can use any option. If you know how to use SQL, then you can use
         * SQLite. But this is not a requirement. You can use other storage options, such as the
         * internal storage option that we used in PA1. If you want to use that option, please
         * take a look at the code for PA1.
         */

        Log.v("inserting values", values.toString());
        return uri;
    }

    @Override
    public boolean onCreate() {
        // If you need to perform any one-time initialization task, please do it here.
        return false;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {

        SQLiteDatabase myDB= null;
        try {
            myDB = new SQLiteDatabase(this.getContext());
            myDB.getReadableDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        android.database.sqlite.SQLiteDatabase sqlDatabase = myDB.getReadableDatabase();
        String[] selection1={selection};
        Cursor cursor = sqlDatabase.rawQuery("select `key`,`value` from GrpMessenger where `key`=?",selection1);
//        Cursor cursor = sqlDatabase.query("GrpMessenger",null,"KEY=?",selection1,null,null,null);
//        sqlDatabase.close();
        /*
         * TODO: You need to implement this method. Note that you need to return a Cursor object
         * with the right format. If the formatting is not correct, then it is not going to work.
         *
         * If you use SQLite, whatever is returned from SQLite is a Cursor object. However, you
         * still need to be careful because the formatting might still be incorrect.
         *
         * If you use a file storage option, then it is your job to build a Cursor * object. I
         * recommend building a MatrixCursor described at:
         * http://developer.android.com/reference/android/database/MatrixCursor.html
         */

        Log.v("query", selection);

        return cursor;
    }

    public class SQLiteDatabase extends SQLiteOpenHelper {

        static final int version=2;
        static final String name="PA2.db";
        static final String tableName="GrpMessenger";
        static final String query="CREATE TABLE "+tableName+" (`key` VARCHAR PRIMARY KEY,value VARCHAR);";


        public SQLiteDatabase(Context context1) throws SQLException
        {
            super(context1,name,null,version);
            Log.e("database","database is created");
            //getReadableDatabase();

        }

        /*public SQLiteHelper(Context context, String database, Object o, int version) {
            super(context, database, null, version);
        }*/

        @Override
        public void onCreate(android.database.sqlite.SQLiteDatabase db) {
            Log.e("database","table is being created");

            db.execSQL(query);
        }

        @Override
        public void onUpgrade(android.database.sqlite.SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    }
}
