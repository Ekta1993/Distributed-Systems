package edu.buffalo.cse.cse486586.simpledht;

public class Node {
    String portNum;
    String succNode;
    String predNode;
    String nodeId;
    String succ_pnum;
    String pred_pnum;


    public String getPortNum() {
        return portNum;
    }

    public void setPortNum(String portNum) {
        this.portNum = portNum;
    }

    public String getSuccNode() {
        return succNode;
    }

    public void setSuccNode(String succNode) {
        this.succNode = succNode;
    }

    public String getPredNode() {
        return predNode;
    }

    public void setPredNode(String predNode) {
        this.predNode = predNode;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getSucc_pnum() {
        return succ_pnum;
    }

    public void setSucc_pnum(String succ_pnum) {
        this.succ_pnum = succ_pnum;
    }

    public String getPred_pnum() {
        return pred_pnum;
    }

    public void setPred_pnum(String pred_pnum) {
        this.pred_pnum = pred_pnum;
    }
}
