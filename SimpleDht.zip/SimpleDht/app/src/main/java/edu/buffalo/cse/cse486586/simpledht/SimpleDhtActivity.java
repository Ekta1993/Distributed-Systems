package edu.buffalo.cse.cse486586.simpledht;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Formatter;

public class SimpleDhtActivity extends Activity {

    static final int[] avdArray = {5562, 5556, 5554, 5558, 5560};

    String new_port;

    Uri contentUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_dht_main);

        TelephonyManager telMan = (TelephonyManager) getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = telMan.getLine1Number().substring(telMan.getLine1Number().length() - 4);
        new_port = String.valueOf(Integer.parseInt(portStr) * 2);
        ServerSocket socket = null;
        try {
            socket = new ServerSocket(10000);
        } catch (IOException e) {
            e.printStackTrace();
        }
        new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,socket);
        new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        findViewById(R.id.button3).setOnClickListener(
                new OnTestClickListener(tv, getContentResolver()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_simple_dht_main, menu);
        return true;
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {

            if (!new_port.equals("5554")) {
                Socket soc = null;

                try {
                    soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            5554*2);
                    OutputStreamWriter os = new OutputStreamWriter(soc.getOutputStream());
                    os.write("ALIVE_REQ" + ":" + Integer.parseInt(new_port)/2 );
                    os.flush();
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;


        }
    }

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        boolean[] portList = {false, false, true, false, false};




        private String genHash(String input) throws NoSuchAlgorithmException {
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            byte[] sha1Hash = sha1.digest(input.getBytes());
            Formatter formatter = new Formatter();
            for (byte b : sha1Hash) {
                formatter.format("%02x", b);
            }
            return formatter.toString();
        }

        private String checkNode(String key) {
            ArrayList<String> current_list = new ArrayList<String>();
            String hashofkey = "";
            try {
                hashofkey = genHash(key);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            for (int i = 0; i < 5; i++) {
                if (portList[i]) {
                    current_list.add(Integer.toString(avdArray[i]));
                }
            }
            for (int i = 0; i < current_list.size()-1; i++) {
                try {
                    if (hashofkey.compareTo(genHash(current_list.get(i))) > 0 && hashofkey.compareTo(genHash(current_list.get(i + 1))) < 0)
                        return current_list.get(i + 1);
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            return current_list.get(0);
        }

        @Override
        protected Void doInBackground(ServerSocket... serverSockets) {
            ServerSocket serverSocket = serverSockets[0];


            while (true) {
                try {
                    Socket server = serverSocket.accept();
                    Log.e("opened the port", "opened port");

                    DataInputStream input = new DataInputStream(server.getInputStream());
                    String msg_string = input.readLine();
                    Log.e("message",msg_string);

                    String[] splits = msg_string.split(":");

                    String msg = splits[0];

                    if (msg.equalsIgnoreCase("INSERT")) {
                        String myKey = splits[1];
                        String myValue = splits[2];
                        SimpleDhtProvider.SQLiteDb sqlDB = null;

                        ContentValues values = new ContentValues();
                        values.put("key",myKey+":");
                        values.put("value",myValue);
                        OutputStreamWriter writer = new OutputStreamWriter(server.getOutputStream());
                        writer.write("ok\n");
                        writer.flush();
                        writer.close();
                        input.close();


                        getContentResolver().insert(contentUri,values);

                    }

                    if (msg.equalsIgnoreCase("ALIVE_REQ")) {

                        String avdNum = splits[1];
                        //5562,5556,5554,5558,5560
                        if (avdNum.equals("5562")) {
                            portList[0] = true;
                        } else if (avdNum.equals("5556")) {
                            portList[1] = true;
                        } else if (avdNum.equals("5558")) {
                            portList[3] = true;
                        } else if (avdNum.equals("5560")) {
                            portList[4] = true;
                        }

                    }

                    if (msg.equalsIgnoreCase("WHICH_AVD")) {
                        Log.e("request",splits[1]);
                        String key = splits[1];
                        String resultAVD = checkNode(key);
                        OutputStreamWriter os = new OutputStreamWriter(server.getOutputStream());
                        Log.e("writing" ,splits[1]+":"+resultAVD);
                        os.write(resultAVD+"\n");
                        os.flush();
                        os.close();
                        input.close();

                    }

                    if(msg.equals("QUERY"))
                    {
                        Cursor cursor = getContentResolver().query(contentUri,null,splits[1],null,null);
                        int keyIndex = cursor.getColumnIndex("key");
                        int valueIndex = cursor.getColumnIndex("value");
                        cursor.moveToFirst();
                        String value = cursor.getString(valueIndex);
                        OutputStreamWriter os = new OutputStreamWriter(server.getOutputStream());
                        os.write(value+"\n");
                        os.flush();
                        cursor.close();

                    }

                    if(msg.equals("AT"))
                    {
                        Cursor cursor = getContentResolver().query(contentUri,null,"@",null,null);

                        int keyIndex = cursor.getColumnIndex("key");
                        int valueIndex = cursor.getColumnIndex("value");
                        OutputStreamWriter os = new OutputStreamWriter(server.getOutputStream());


                        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                            String key = cursor.getString(keyIndex);
                            String value = cursor.getString(valueIndex);
                            os.write(key+"|"+value+"\n");

                        }
                        os.write("end\n");
                        os.flush();
                        cursor.close();


                    }
                    if(msg.equals("DELETE"))
                    {
                        String myKey = splits[1];

                        OutputStreamWriter writer = new OutputStreamWriter(server.getOutputStream());
                        writer.write("ok\n");
                        writer.flush();
                        writer.close();
                        input.close();
                        getContentResolver().delete(contentUri,myKey+"-",null);
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }



}
