package edu.buffalo.cse.cse486586.simpledht;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.LinkedList;

public class SimpleDhtProvider extends ContentProvider {
    static final String PORT1 = "11108";
    static final String PORT2 = "11112";
    static final String PORT3 = "11116";
    static final String PORT4 = "11120";
    static final String PORT5 = "11124";
    static final int SERVER = 10000;
    static final String tag = SimpleDhtActivity.class.getSimpleName();
    private static final String KEY = "key";
    private static final String VALUE = "value";
    static String new_port;
    static String avd_num;
    static LinkedList<Node> mylist = new LinkedList<Node>();
    int ports[] = {11108, 11112, 11116, 11120, 11124};
    Node node = new Node();
    SQLiteDb db;


    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        SQLiteDatabase mydb = db.getWritableDatabase();
        if(selection.contains("-"))
        {
            String args[] = {selection.substring(0,selection.length()-1)};
            return mydb.delete("dbtable","key=?",args);
        }
        try {


            Socket soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(PORT1));   // send 'Join' request to emulator 5554 (AVD0)
            OutputStreamWriter os = new OutputStreamWriter(soc.getOutputStream());
            os.write("WHICH_AVD:" + selection + "\n");
            os.flush();
            BufferedReader is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
            String avd = is.readLine();
            is.close();
            os.close();
            if(avd==null || avd.equals(avd_num))
            {
                String args[] = {selection};
                return mydb.delete("dbtable","key=?",args);
            }
            else
            {
                soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(avd) * 2);   // send 'Join' request to emulator 5554 (AVD0)
                os = new OutputStreamWriter(soc.getOutputStream());
                os.write("DELETE:"+selection+"\n");
                os.flush();
                is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                String line = is.readLine();
                if(line.equals("ok"))
                {
                    Log.e("received ok","insert");
                }

            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            String args[] = {selection};
            return mydb.delete("dbtable","key=?",args);

        }


        return 0;

    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub

        String key = (String) values.get("key");
        String val = (String) values.get("value");
        SQLiteDb sqlDB = db;
        SQLiteDatabase mydb = sqlDB.getWritableDatabase();
        if(key.endsWith(":"))
        {
            key = key.substring(0,key.length()-1);
            ContentValues vall = new ContentValues();
            vall.put("key",key);
            vall.put("value",val);
            Log.e("inserting directly",key+":"+val);

            mydb.insertWithOnConflict("dbtable", null, vall, SQLiteDatabase.CONFLICT_REPLACE);
            return uri;




        }

        Log.e("insert","start");


        try {
            Log.e("insert","start1");
            Socket soc = null;
            soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(PORT1));   // send 'Join' request to emulator 5554 (AVD0)
            Log.e("insert","start2"+":"+key);
            OutputStreamWriter os = new OutputStreamWriter(soc.getOutputStream());
            os.write("WHICH_AVD:" + key + "\n");
            os.flush();
            Log.e("insert","start21"+":"+key);
            BufferedReader is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
            String avd = is.readLine();
            Log.e("insert","start22"+":"+key);


            Log.e("insert","start3");
            if (avd == null || avd.equals(avd_num))
                mydb.insertWithOnConflict("dbtable", null, values, SQLiteDatabase.CONFLICT_REPLACE);
            else {
                Log.e("inserting",key+" into "+avd);
                soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(avd) * 2);   // send 'Join' request to emulator 5554 (AVD0)
                os = new OutputStreamWriter(soc.getOutputStream());
                os.write("insert:"+key+":"+val+"\n");
                os.flush();
                is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                String line = is.readLine();
                if(line.equals("ok"))
                {
                    Log.e("received ok","insert");
                }
            }
        } catch (Exception e) {
            mydb.insertWithOnConflict("dbtable", null, values, SQLiteDatabase.CONFLICT_REPLACE);

            e.printStackTrace();
        }
        Log.e("insert","end");
        return uri;
    }

    @Override
    public boolean onCreate() {
        // TODO Auto-generated method stub
        TelephonyManager telMan = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = telMan.getLine1Number().substring(telMan.getLine1Number().length() - 4);
        avd_num = String.valueOf(Integer.parseInt(portStr));
        new_port = String.valueOf(Integer.parseInt(portStr) * 2);
        try {
            db = new SQLiteDb(this.getContext());
        } catch (SQLException e1) {
            e1.printStackTrace();
        }

        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        Cursor cursor = null;


        SQLiteDatabase mydb = db.getReadableDatabase();

        if (selection.equals("@")) {
            cursor = mydb.query("dbtable", null, null, null, null, null, null, null);
            return cursor;
        } else {
            Socket soc = null;
            String avd = "";
            try {
                if (!selection.equals("*")) {

                    if(selection.endsWith("-")) {
                        String args[] = {selection.substring(0,selection.length()-1)};
                        Log.e(args[0],"hey");

                        cursor =  mydb.query("dbtable", null, "key='"+args[0]+"'", null, null, null, null);
                        Cursor cursor1 = mydb.query("dbtable",null,null,null,null,null,null);
                    Log.e("cursor - single",DatabaseUtils.dumpCursorToString(cursor));
                    Log.e("cursor - single",DatabaseUtils.dumpCursorToString(cursor1));
                    return cursor;

                    }


                    soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(PORT1));   // send 'Join' request to emulator 5554 (AVD0)
                    OutputStreamWriter os = new OutputStreamWriter(soc.getOutputStream());
                    os.write("WHICH_AVD:" + selection + "\n");
                    os.flush();
                    BufferedReader is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                    avd = is.readLine();
                    is.close();
                    os.close();

                    if (avd==null|| avd.equals(avd_num) ){

                        String args[] = {selection};
                        return mydb.query("dbtable", null, "key=?", args, null, null, null);
                    } else {
                        soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),Integer.parseInt(avd)*2);   // send 'Join' request to emulator 5554 (AVD0)
                        os = new OutputStreamWriter(soc.getOutputStream());
                        os.write("QUERY:" + selection + "-\n");
                        os.flush();
                        is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                        String line = is.readLine();
                        String columns[] = {"key", "value"};
                        MatrixCursor matcur = new MatrixCursor(columns);
                        String row[] = {selection, line};
                        matcur.addRow(row);
                        is.close();
                        os.close();
                        return matcur;
                    }
                } else {
                    String columns[] = {"key", "value"};
                    MatrixCursor matcur = new MatrixCursor(columns);
                    for (int i = 0; i < 5; i++) {
                        try {
                            Log.e("inside","*");


                            soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), ports[i]);
                            OutputStreamWriter os = new OutputStreamWriter(soc.getOutputStream());
                            os.write("AT" + "\n");
                            os.flush();
                            BufferedReader is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                            String line = is.readLine();
                            Log.e("line:",line);
                            while (line != null && !line.equals("end")) {
                                String tup[] = line.split("\\|");
                                Log.e(tup[0],tup[1]);
                                matcur.addRow(new Object[]{tup[0],tup[1]});
                                line = is.readLine();

                            }
                        }
                        catch (Exception e)
                        {
                            Log.e("inside","crash");
                            e.printStackTrace();

                        }


                    }
                    Log.e(DatabaseUtils.dumpCursorToString(matcur),"");
                    return matcur;


                }
            } catch (IOException e) {
                String args[] = {selection};
                return mydb.query("dbtable", null, "key=?", args, null, null, null);

            }


        }
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }


    public class SQLiteDb extends SQLiteOpenHelper {

        static final int version = 2;
        static final String name = "PA3.db";
        static final String db_table = "dbtable";
        static final String cursor_table = "cursortable";
        static final String cursor_table_star = "cursortableStar";
        static final String query1 = "CREATE TABLE " + db_table + " (`key` VARCHAR PRIMARY KEY,value VARCHAR);";
        static final String query2 = "CREATE TABLE " + cursor_table + " (`key` VARCHAR PRIMARY KEY,value VARCHAR);";
        static final String query3 = "CREATE TABLE " + cursor_table_star + " (`key` VARCHAR PRIMARY KEY,value VARCHAR);";


        public SQLiteDb(Context context1) throws SQLException {
            super(context1, name, null, version);
            Log.e("database", "database is created");
            //getReadableDatabase();

        }

        /*public SQLiteHelper(Context context, String database, Object o, int version) {
            super(context, database, null, version);
        }*/

        @Override
        public void onCreate(android.database.sqlite.SQLiteDatabase db) {
            Log.e("dbtable", "table is being created");


            //db.execSQL(query);
            db.execSQL(query1);
            db.execSQL(query2);
            db.execSQL(query3);
        }

        @Override
        public void onUpgrade(android.database.sqlite.SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    }

    class HashCodeComparator implements Comparator<Node> {
        @Override
        public int compare(Node node, Node t1) {
            int value = node.getNodeId().compareTo(t1.getNodeId());
            if (value < 0)
                return -1;
            else if (value > 0)
                return 1;

            return 0;
        }
    }
}
