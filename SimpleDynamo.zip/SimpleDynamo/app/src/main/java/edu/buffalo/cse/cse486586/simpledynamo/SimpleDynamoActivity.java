package edu.buffalo.cse.cse486586.simpledynamo;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
public class SimpleDynamoActivity extends Activity {

	String new_port;
	String avdNum;
	Boolean recoveryDone = false;

	Uri contentUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.provider");

	private Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_simple_dynamo);

		TelephonyManager telMan = (TelephonyManager) getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = telMan.getLine1Number().substring(telMan.getLine1Number().length() - 4);
		avdNum = portStr;
		new_port = String.valueOf(Integer.parseInt(portStr) * 2);
		ServerSocket socket = null;
		getContentResolver().delete(contentUri,"*",null);
		new recoverTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,socket);


		TextView tv = (TextView) findViewById(R.id.textView1);
		tv.setMovementMethod(new ScrollingMovementMethod());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.simple_dynamo, menu);
		return true;
	}

	private class recoverTask extends AsyncTask
    {

		class ListNode {
			public ListNode next;
			public ListNode prev;
			public String data;

			public ListNode(String data, ListNode prev) {
				if(prev !=null)
					prev.next = this;
				this.prev = prev;
				this.data = data;
			}
		}


		private ArrayList<String> getSucc(String avd) {


            int[] avdArray = {5562, 5556, 5554, 5558, 5560};
            ListNode head = new ListNode(Integer.toString(avdArray[0]),null);
            ListNode prev = head;
            head.prev = prev;
            Log.e("","entering get succ");
            for(int i =1 ; i < 5;i++)
            {
                prev = new ListNode(Integer.toString(avdArray[i]),prev);

            }
            prev.next = head;

            while (!head.data.equals(avd))
            {
                prev = head;
                head = head.next;
            }
            ArrayList<String> ans=  new ArrayList<String>();
            ans.add(head.next.data);
            ans.add(head.next.next.data);
            Log.e("","exiting get succ");
            return ans;
        }

		private ArrayList<String> getPred(String avd) {



			int[] avdArray = {5562, 5556, 5554, 5558, 5560};
			ListNode head = new ListNode(Integer.toString(avdArray[0]),null);
			ListNode prev = head;
			Log.e("","entering get pred");
			for(int i =1 ; i < 5;i++)
			{
				prev = new ListNode(Integer.toString(avdArray[i]),prev);

			}
			prev.next = head;
			head.prev = prev;


			while (!head.data.equals(avd))
			{
				prev = head;
				head = head.next;
			}
			ArrayList<String> ans=  new ArrayList<String>();
			ans.add(head.prev.data);
			ans.add(head.prev.prev.data);
			Log.e("","exiting get prev");
			return ans;
		}

        @Override
        protected Object doInBackground(Object[] objects) {


            Log.e("server","recovering");
            ArrayList<String> succ = getSucc(avdNum);
            for(String suc :succ)
            {
                Socket socket;
                try {
                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(suc)*2);
                    if(socket.isConnected()) {
                        OutputStreamWriter os = new OutputStreamWriter(socket.getOutputStream());
                        os.write("RECOVERY|" + avdNum + "\n");
                        Log.e("succ|"+suc+"|","RECOVERY|" + avdNum + "\n");
                        os.flush();

                        BufferedReader is = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String line = is.readLine();

                        while (line != null) {
                            String tuple[] = line.split("\\|");
                            Log.e("line",line);
                            ContentValues values = new ContentValues();
                            values.put("key", tuple[0] + ":");
                            values.put("value", tuple[1]);
                            values.put("avdNum", avdNum);
                            getContentResolver().insert(contentUri, values);
                            line = is.readLine();
                        }
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

			ArrayList<String> pred = getPred(avdNum);
			for(String suc :pred)
			{
				Socket socket;
				try {
					Log.e("pred|"+suc+"|","RECOVERY|" + avdNum + "\n");
					socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(suc)*2);
					if(socket.isConnected()) {
						OutputStreamWriter os = new OutputStreamWriter(socket.getOutputStream());
						os.write("ONLY\n");
						os.flush();

						BufferedReader is = new BufferedReader(new InputStreamReader(socket.getInputStream()));
						String line = is.readLine();


						while (line != null) {
							Log.e("line",line);
							String tuple[] = line.split("\\|");
							ContentValues values = new ContentValues();
							values.put("key", tuple[0] + ":");
							values.put("value", tuple[1]);
							values.put("avdNum", suc);
							getContentResolver().insert(contentUri, values);
							line = is.readLine();

						}
					}

				} catch (IOException e) {
					e.printStackTrace();
				}

			}

            recoveryDone = true;
			ContentValues values = new ContentValues();
			values.put("key","RECOVERY");
			getContentResolver().insert(contentUri,values);



            Log.e("server","recovery complete");
            return null;
        }
    }

	private class ServerTask extends AsyncTask<ServerSocket, String, Void>{







		@Override
		protected Void doInBackground(ServerSocket... serverSockets) {
			ServerSocket serverSocket = serverSockets[0];
			ArrayList<String> succ = null;

			ServerSocket ss= null;
			try {
				ss = new ServerSocket(10000);
			} catch (IOException e) {
				e.printStackTrace();
			}


			while (true) {

				try {
					Socket server = ss.accept();

					Log.e("opened the port", "opened port");

					DataInputStream input = new DataInputStream(server.getInputStream());
					String msg_string = input.readLine();
					Log.e("message",msg_string);

					String[] splits = msg_string.split("\\|");

					String msg = splits[0];
//					if(recoveryDone == false  )
//					{
//						server.close();
//						continue;
//					}
					if(recoveryDone == false)

					while ( recoveryDone == false && !(msg.equals("RECOVERY") || msg.equals("ONLY")))
                    {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }


					if (msg.equalsIgnoreCase("INSERT")) {
						String myKey = splits[1];
						String myValue = splits[2];

						SimpleDynamoProvider.SQLiteDb sqlDB = null;


						ContentValues values = new ContentValues();
						values.put("key",myKey+":");
						values.put("value",myValue);
						values.put("avdNum",splits[3]);
						OutputStreamWriter writer = new OutputStreamWriter(server.getOutputStream());
						writer.write("ok\n");
						writer.flush();
						writer.close();
						input.close();

						getContentResolver().insert(contentUri,values);

					}


					else if( msg.equals("AT") || msg.equals("ONLY") || msg.equals("QUERY") || msg.equals("RECOVERY"))
					{
						Cursor cursor;
						if(msg.equals("RECOVERY"))
						{
							String args[] = {splits[1]};
							cursor = getContentResolver().query(contentUri,null ,"avdNum = ?",args,null,null);
							DatabaseUtils.dumpCursorToString(cursor);

						}
						else if(msg.equals("QUERY"))
						{
							String selargs[] = {splits[1]};
							cursor = getContentResolver().query(contentUri,null,"key = ?",selargs,null,null);
						}
						else if(msg.equals("AT"))
						{
							cursor = getContentResolver().query(contentUri,null,"@1",null,null);

						}
						else {
							cursor = getContentResolver().query(contentUri, null, "ONLY", null, null);
						}
						int keyIndex = cursor.getColumnIndex("key");
						int valueIndex = cursor.getColumnIndex("value");
						int verNumIndex = cursor.getColumnIndex("verNum");
						OutputStreamWriter os = new OutputStreamWriter(server.getOutputStream());


						for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
							String key = cursor.getString(keyIndex);
							String value = cursor.getString(valueIndex);
							String verNum = cursor.getString(verNumIndex);
 							os.write(key+"|"+value+"|"+verNum+"\n");
 							Log.e("sending for only", key+"|"+value+"|"+verNum+"\n");

						}
						Log.e("Complete","send");
						cursor.close();
						os.flush();
						os.close();
						input.close();
					}

					if(msg.equals("DELETE"))
					{
						String myKey = splits[1];
						Log.e("inside del",splits[1]);

						OutputStreamWriter writer = new OutputStreamWriter(server.getOutputStream());
						Log.e("sending ok for del ",splits[1]);
						writer.write("ok\n");

						writer.flush();
						writer.close();
						input.close();
						Log.e("del result", Integer.toString( getContentResolver().delete(contentUri,myKey+"-",null)));

					}


				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public void onStop() {
        super.onStop();
	    Log.v("Test", "onStop()");
	}

}
