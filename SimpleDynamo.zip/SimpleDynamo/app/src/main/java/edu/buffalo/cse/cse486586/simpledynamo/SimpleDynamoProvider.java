package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Array;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Formatter;
import java.util.HashMap;
import java.util.LinkedList;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDynamoProvider extends ContentProvider {

	static final String PORT1 = "11108";
	static final String PORT2 = "11112";
	static final String PORT3 = "11116";
	static final String PORT4 = "11120";
	static final String PORT5 = "11124";
	static final int SERVER = 10000;
	static final String tag = SimpleDynamoActivity.class.getSimpleName();
	private static final String KEY = "key";
	private static final String VALUE = "value";
	private static final String verNum = "verNum";
	static String new_port;
	static String avd_num;


	int ports[] = {11108, 11112, 11116, 11120, 11124};

	SQLiteDb db;

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		SQLiteDatabase mydb = db.getWritableDatabase();
		Log.e("delete",selection);
		if(selection.contains("-"))
		{
			String args[] = {selection.substring(0,selection.length()-1)};
			return mydb.delete("dbtable","key=?",args);
		}
		if(selection.equals("*"))
        {
        	mydb.delete("recovery_table",null,null);
            mydb.delete("dbtable",null,null);
            return 0;
        }

		    ArrayList<String> nodes =  checkCircularNode(selection);

                for(String node : nodes) {
                    try {
                    	Log.e("sending delete",node);
                        Socket soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(node) * 2);   // send 'Join' request to emulator 5554 (AVD0)
                        OutputStreamWriter os = new OutputStreamWriter(soc.getOutputStream());
                        os.write("DELETE|" + selection + "\n");
                        os.flush();
                        BufferedReader is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                        String line = is.readLine();
                        if (line.equals("ok")) {
                            Log.e("received ok", "delete");
                        }
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                return  0;
		}


	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	class ListNode {
		public ListNode next;
		public ListNode prev;
		public String data;

		public ListNode(String data, ListNode prev) {
		    if(prev!=null) {
                prev.next = this;
            }
            this.prev = prev;
			this.data = data;
		}
	}

	private ArrayList<String> checkCircularNode(String key) {

		int[] avdArray = {5562,5556,5554,5558, 5560};
		ListNode head = new ListNode(Integer.toString(avdArray[0]),null);
		ListNode prev = head;
		for(int i =1 ; i < 5;i++)
		{
			prev = new ListNode(Integer.toString(avdArray[i]),prev);

		}

		prev.next = head;
		head.prev = prev;

		boolean issecond = false;

		try {
            while (!(genHash(key).compareTo(genHash(prev.data)) > 0 && genHash(key).compareTo(genHash(head.data)) < 0)) {
                if ((head.data.equals("5562")) && issecond)
                {
                    break;
                }
                issecond = true;
                prev = head;
                head = head.next;
            }
        }catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
		ArrayList<String> ans=  new ArrayList<String>();
		ans.add(head.data);
		ans.add(head.next.data);
		ans.add(head.next.next.data);

        return ans;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub

		SQLiteDb sqlDB = db;
		SQLiteDatabase mydb = sqlDB.getWritableDatabase();

		String key = (String) values.get("key");
		if(key.equals("RECOVERY"))
		{
			mydb.insert("recovery_table",null,values);
			return uri;
		}
		String val = (String) values.get("value");
		String avdNum =(String) values.get("avdNum");
		int verNum= 0;


		if(key.endsWith(":"))
		{
			key = key.substring(0,key.length()-1);
			ContentValues vall = new ContentValues();
			vall.put("key",key);
			vall.put("value",val);
			vall.put("avdNum",checkCircularNode(key).get(0));
			Log.e("inserting directly",key+":"+val+":"+avdNum);

			Cursor cursor=null;
			String args[] = {key};
			cursor =  mydb.query("dbtable", null, "key= ?", args, null, null, null);
			if(cursor.getCount() ==0){
				vall.put("verNum",verNum);
			}
			else{
				vall.put("verNum",verNum+1);
			}
			vall.put("avdNum",avdNum);


			mydb.insertWithOnConflict("dbtable", null, vall, SQLiteDatabase.CONFLICT_REPLACE);
			return uri;
		}

		Log.e("insert","start");

		Socket soc=null;
		ArrayList<String> listofPorts= new ArrayList<String>();
		listofPorts = checkCircularNode(key);


			for(int i=0;i<listofPorts.size();i++)
			{
				try {
			soc=new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(listofPorts.get(i))*2);
			Log.e("insert","sending it to "+listofPorts.get(i)+":"+key);
			OutputStreamWriter os =new OutputStreamWriter(soc.getOutputStream());
    		BufferedReader is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			os.write("INSERT|" + key+"|"+val+"|"+listofPorts.get(0)+"\n");
			os.flush();


			String avd =is.readLine();
			if(avd == null)
			{
				Log.e("insert fail","got null" + "INSERT|" + key+"|"+val+"|"+listofPorts.get(0)+"\t"+listofPorts.get(i));

			}
			else if(avd.equals("ok"))
            {
                Log.e("got ok","ok");
            }
			}
				catch (IOException e) {
					Log.e("insert fail","INSERT|" + key+"|"+val+"|"+listofPorts.get(0)+"\t"+listofPorts.get(i));
				}

		}
        return uri;
	}

	@Override
	public boolean onCreate() {
		TelephonyManager telMan = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = telMan.getLine1Number().substring(telMan.getLine1Number().length() - 4);
		avd_num = String.valueOf(Integer.parseInt(portStr));
		new_port = String.valueOf(Integer.parseInt(portStr) * 2);
		try {
			db = new SQLiteDb(this.getContext());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {

		Cursor cursor = null;


		SQLiteDatabase mydb = db.getReadableDatabase();

		if(selection.contains("?"))
        {
            cursor = mydb.query("dbtable",null,selection,selectionArgs,null,null,null);
              return cursor;
        }
        else if(selection.equals("@")) {
			while (mydb.query("recovery_table", null, null, null, null, null, null).getCount() <= 0) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			String atargs[] = {"key","value"};
             cursor =  mydb.query("dbtable",atargs,null,null,null,null,null);
             return cursor;

        }
		else if(selection.equals("@1"))
		{
			String atargs[] = {"key","value","verNum"};
			cursor =  mydb.query("dbtable",atargs,null,null,null,null,null);
			return cursor;

		}

        else if(selection.equals("ONLY"))
        {

            String atargs[] = {"key","value","verNum"};
            String selargs[] = {avd_num};
            cursor = mydb.query("dbtable",atargs,"avdNum = ?",selargs,null,null,null,null);
            return cursor;
        }

        else if(selection.equals("*"))
        {
            Log.e("inside star","hello");
            Socket soc;
            String columns[] = {"key", "value"};
            Log.e("inside star","hello1");
            OutputStreamWriter os;
            Log.e("inside star","hello2");
            BufferedReader is;
            Log.e("inside star","hello3");
            Log.e("inside star","");
            MatrixCursor matcur = new MatrixCursor(columns);
            Log.e("inside star","");
			HashMap<String,String> hmap = new HashMap<String, String>();

            for(int i =0 ; i < 5;i++) {
                try {

                    soc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), ports[i]);   // send 'Join' request to emulator 5554 (AVD0)
                    is = new BufferedReader(new InputStreamReader(soc.getInputStream()));
                    os = new OutputStreamWriter(soc.getOutputStream());
                    os.write("AT\n" );
                    os.flush();
                    String line = is.readLine();
                    while (line != null) {

                        String tup[] = line.split("\\|");
                        Log.e("","adding row");
                        hmap.put(tup[0],tup[1]);

                        Log.e("","added row");
                        line = is.readLine();
                    }
                    Log.e("complete read","read");

                }catch (Exception e)
                {

                }

            }
            for(String key : hmap.keySet())
			{
				matcur.newRow().add(key).add(hmap.get(key)) ;

			}
            return matcur;


        }

		else
        {
            ArrayList<String> possibleavd =  checkCircularNode(selection);
            Integer currentVer = -1;
            String currVal ="";
            for(String avd : possibleavd)
            {
                try {

                    Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(avd) * 2);
                    OutputStreamWriter writer = new OutputStreamWriter(socket.getOutputStream());
                    writer.write("QUERY|"+selection+"\n");
                    writer.flush();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String line = reader.readLine();
                    if(line != null) {
						Log.e(" got", line);
						String querySplit[] = line.split("\\|");
						if (Integer.parseInt(querySplit[2]) > currentVer) {
							currentVer = Integer.parseInt(querySplit[2]);
							currVal = querySplit[1];
						}
					}
                    writer.close();
                    reader.close();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

            }
            String columns[] = {"key", "value"};
            MatrixCursor matcur = new MatrixCursor(columns);
            String row[] = {selection,currVal};
            matcur.newRow().add("key",selection).add("value",currVal);
            return matcur;

        }

	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

	public class SQLiteDb extends SQLiteOpenHelper {

		static final int version = 2;
		static final String name = "PA3.db";
		static final String db_table = "dbtable";
		static final String recovery_table = "recovery_table";
		static final String cursor_table = "cursortable";
		static final String cursor_table_star = "cursortableStar";
		static final String query1 = "CREATE TABLE " + db_table + " (`key` VARCHAR PRIMARY KEY,value VARCHAR,verNum VARCHAR,avdNum VARCHAR);";
		static final String query2 = "CREATE TABLE " + recovery_table + " (`key` VARCHAR PRIMARY KEY);";


		public SQLiteDb(Context context1) throws SQLException {
			super(context1, name, null, version);
			Log.e("database", "database is created");

		}


		@Override
		public void onCreate(android.database.sqlite.SQLiteDatabase db) {
			Log.e("dbtable", "table is being created");
			db.execSQL(query1);
			db.execSQL(query2);
			}

		@Override
		public void onUpgrade(android.database.sqlite.SQLiteDatabase db, int oldVersion, int newVersion) {

		}
	}
}
